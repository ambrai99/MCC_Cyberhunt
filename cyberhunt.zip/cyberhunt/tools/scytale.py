#!/usr/bin/env python3
"""Scytale strip generator and wrong-dowel tester.

Usage:  python3 scytale.py [MESSAGE] [LETTERS_PER_TURN] [PITCH_INCHES]
Defaults: USERNAMEISAGENT7, 4 letters per turn, 0.49 in letter spacing.

Model: the strip is wound edge to edge. A dowel that fits k letters around
its circumference shows the message in k rows running along its length.
Letters per turn on a dowel = pi * diameter / letter pitch.
"""
import math, sys

def encode(msg, k):
    msg = msg.upper().replace(" ", "")
    while len(msg) % k: msg += "X"
    m = len(msg) // k
    strip = [""] * len(msg)
    for a in range(k):
        for r in range(m):
            strip[a + k * r] = msg[a * m + r]
    return "".join(strip)

def read_on(strip, k):
    """What a student sees on a dowel that fits k letters per turn (rounded)."""
    L = len(strip); m = -(-L // k); out = []
    for a in range(k):
        row = ""
        for r in range(m):
            i = a + k * r
            if i < L: row += strip[i]
        out.append(row)
    return out

if __name__ == "__main__":
    msg = sys.argv[1] if len(sys.argv) > 1 else "USERNAMEISAGENT7"
    k = int(sys.argv[2]) if len(sys.argv) > 2 else 4
    pitch = float(sys.argv[3]) if len(sys.argv) > 3 else 0.49
    strip = encode(msg, k)
    print(f"Strip text: {strip}  ({len(strip)} letters, {len(strip)*pitch:.2f} in long)\n")
    print("Dowel     Diameter  Letters/turn  What the student reads (rows top to bottom)")
    for name, d in [("3/8 in", .375), ("1/2 in", .5), ("5/8 in", .625), ("3/4 in", .75), ("7/8 in", .875), ("1 in", 1.0)]:
        lpt = math.pi * d / pitch
        rows = read_on(strip, round(lpt))
        tag = "  <-- RIGHT DOWEL" if name == "5/8 in" else ""
        print(f"{name:<9} {d:<9} {lpt:<13.2f} {' / '.join(rows)}{tag}")
