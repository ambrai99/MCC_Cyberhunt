# Cyber Student Day hunt: setup and answer key

## What's in the package

```
site/      Upload the CONTENTS of this folder to your GitHub repo (index.html must sit at the repo root)
print/     Open these in a browser to print: strips.html, wheels.html, cards.html
tools/     scytale.py (strip generator and wrong-dowel tester), hash.html (change usernames/passwords)
```

## Student path and answers

| Step | What the student does | Answer |
|---|---|---|
| 1. Scytale | Wraps the strip on dowels until one gives readable words | Message `USERNAMEISAGENT7`, so username is **agent7** |
| 2. Caesar | Decodes `MPYLDHSS` on the wheel. The 7 in the username is the shift | Password is **FIREWALL** |
| 3. Portal login | Scans the QR on the card and signs in | Opens the intranet |
| 4. OSINT | Finds the Finance employee (Dana), reads her profile, tries the pet name | **d.reyes / biscuit** |
| 5. Final page | Enters a first name and gets a badge with the rotating code word | Shows the word to faculty |

Decoys that look right but fail: Dana's dead cat Pepper, her sister's birthday, her own birthday (3/14/1992). Valid but wrong target: **m.tran / 7/22/1991** (Marcus, IT) and **p.nair / mocha** (Priya, HR). Both show "Access denied: nice work, wrong target." Birthdays are accepted with or without slashes and with 2 or 4 digit years.

Three failed employee logins lock the form for 30 seconds. Change this in `site/js/config.js` (`maxAttempts`, `lockSeconds`).

## Put it online (GitHub Pages)

1. In your repo, choose **Add file, Upload files**.
2. Drag in everything **inside** the `site` folder (`index.html`, the profile and other pages, `css/`, `js/`). Commit.
3. **Settings, Pages**, deploy from branch `main`, folder `/ (root)`. Wait a couple of minutes.
4. Your URL will look like `https://YOURNAME.github.io/REPONAME/`. Open it on a phone over cellular, not just Wi-Fi.
5. Put that URL into `print/cards.html` (the QR codes need an internet connection to draw), and scan one before printing a stack.

Faculty page for the code word: `YOUR-URL/staff.html`. It's not linked from anywhere. Bookmark it on a faculty phone. It shows the current word, the previous word (also valid), and a schedule of the next 4 hours.

## Code word rules

Words rotate every 30 minutes on the phone's clock, so every phone agrees. Accept the **current or previous** word so a student who finishes at the boundary isn't rejected. The badge also shows the student's name and the time to the second, so an old screenshot is easy to spot.

## Supplies

- **Dowels:** 36 in lengths cut into 6 in pieces, in five sizes: 3/8, 1/2, **5/8 (the right one)**, 3/4, 7/8. Make 6 to 8 of each and mix them in bins. Skip 1 in. It reads the same as 7/8.
- **Strips:** printed from `print/strips.html`, landscape, 100% scale, 26 per two pages. Print 100+ and keep a stack at the table.
- **Wheels:** `print/wheels.html`, heavy cardstock. For the table copies: laminate (5 to 10 mil), round the corners, reinforce the center hole, and use a Chicago screw instead of a brad. Tether table copies with a short lanyard. Make a few extra paper wheels for students to keep.
- **Cards:** `print/cards.html`, four per page, 40+ cards.

**Test the dowels before the event.** Nominal 5/8 in dowels often measure a little under. Wrap a printed strip on your actual dowels. If the right one doesn't read cleanly, measure it and set the letter spacing in `strips.html` to (3.1416 x diameter) / 4, then reprint. Wrong dowels should read as obvious nonsense. Here is what each reads with the default settings (run `python3 tools/scytale.py` to regenerate):

| Dowel | Reads |
|---|---|
| 3/8 | UISSEARG / NEANMTE7 |
| 1/2 | UESMR7 / NSNAE / IAETG |
| **5/8** | **USER / NAME / ISAG / ENT7** |
| 3/4 | UAA7 / NST / INR / EEE / SMG |
| 7/8 | USR / NNE / IEG / EM7 / SA / AT |

## Changing things

- **Program name or link on the final page:** `site/js/config.js` (`program`, `programUrl`).
- **Company name:** search and replace "Ironwood Dynamics" across the `site` files and `print/cards.html`.
- **Username or password:** open `tools/hash.html` in a browser, type the new value, paste the hash into `config.js`. If you change the username or password, regenerate the strips (`strips.html` message) and the cipher text in `cards.html`. The Caesar shift is the number in the username.
- **Any other employee login:** each account lists every accepted password hash.

## Before the event

- [ ] Scan the QR code from a printed card on an iPhone and an Android, on cellular
- [ ] Run the whole hunt once start to finish, including a deliberate lockout
- [ ] Confirm `staff.html` shows a word and the badge shows the same word
- [ ] Check the site isn't flagged by your school's filter or by browser safe-browsing warnings (the banner and fictional company names help). Test again the morning of.
- [ ] Keep a backup host ready (Netlify Drop or Cloudflare Pages with the same files)
- [ ] Print the answer key above for the faculty table, in case the site is down

## What the site doesn't do

The answers are hashed but anyone who reads the source can reverse them with effort. A student who gets in that way did a real hack, so give them credit. There is no server, so the lockout can be cleared by clearing browser data, and there is no record of finishers other than the badge screenshot.
